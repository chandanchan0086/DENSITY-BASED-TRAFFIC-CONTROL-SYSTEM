# density based two way traffic signal

Two-way traffic signal using ultrasonic sensor and Arduino which take decisions on the basis of density.

In this video, we are going to make a traffic signal and they will be controlled autonomously by checking the density using the ultrasonic sensor.  A prototype to smart transport.

I have used proteus simulation but you can use the same code for real components.

check video:
https://youtu.be/tCTpH4O0P9Q
